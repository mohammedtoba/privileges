<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateChargesUnitsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('charges_units', function (Blueprint $table) {
            $table->string('unit_cd',5)   ;
            $table->string('unit_nam_ar',255);
            $table->string('unit_nam_en',255);
            $table->string('unit_notes',255);
            $table->string('unit_actv',1);
            $table->timestamps();  
            $table->primary('unit_cd') ;       
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('charges_units');
    }
}

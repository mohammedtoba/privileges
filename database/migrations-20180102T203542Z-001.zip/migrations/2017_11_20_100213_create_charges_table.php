<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateChargesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('charges', function (Blueprint $table) {

            $table->string('charge_no',20);
            $table->string('charge_nam_ar',255);
            $table->string('charge_nam_en',255);
            $table->string('charge_flg',1);
            $table->string('group_no',20)->references('group_no')->on('charges_group');
            $table->string('sub_group_no',20)->references('sub_group_no')->on('charges_sub_group');
            $table->string('profile_dataobject',100);
            $table->string('profile_reportview',100);
            $table->string('profile_table',50);
            $table->decimal('charge_duration', 15, 2)->nullable();
            $table->decimal('charge_amount', 15, 2)->nullable();
            $table->string('sample_typ',3 );
            $table->string('unit_cd',5)->references('unit_cd')->on('charges_units');               
            $table->string('nrm_val_flg',1);
            $table->string('nrm_val_male_f',1);
            $table->string('nrm_val_male_t',1);
            $table->string('nrm_val_female_f',1);
            $table->string('nrm_val_female_t',1);
            $table->string('nrm_val_child_f',1);
            $table->string('nrm_val_child_t',1);
            $table->string('nrm_val_infant_f',1);
            $table->string('nrm_val_infant_t',1);
            $table->string('charge_notes',100);
            $table->decimal('amount', 15, 2)->nullable();
            $table->string('profile_nrm_val',100)->nullable();
            $table->string('lab_flg',1);
            $table->string('comp_cd',10);            
            $table->timestamps();
            $table->primary('charge_no');
         });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('charges');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients', function (Blueprint $table) {

            $table->string('patient_id',50)->primary();
            $table->string('patient_nam_ar', 255);
            $table->string('patient_nam_en', 255);
            $table->date('patient_dob');
            $table->string('patient_gender', 1);
            $table->string('patient_category', 4)->nullable();
            $table->string('patient_natid', 11);
            $table->string('patient_phone', 50)->nullable();
            $table->string('patient_mobile', 20);
            $table->string('patient_email', 100)->unique();
            $table->string('patient_address', 255)->nullable();
            $table->string('patient_nat',5)->references('nat_cd')->on('nationality') ;
            $table->string('patient_city',5)->references('city_cd')->on('cities') ;
            $table->string('patient_notes', 255)->nullable();
            $table->string('patient_actv', 1)->nullable() ;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients');
    }
}

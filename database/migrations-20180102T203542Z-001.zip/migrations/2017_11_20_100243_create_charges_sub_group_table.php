<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateChargesSubGroupTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('charges_sub_group', function (Blueprint $table) {
            $table->string('group_no',20)->references('group_no')->on('charges_group');
            $table->string('sub_group_no',20);
            $table->string('sub_group_nam_ar',255);
            $table->string('sub_group_nam_en',255);
            $table->string('sub_group_notes',255);
            $table->string('sub_group_actv',1);
            $table->timestamps();
            $table->primary(['group_no', 'sub_group_no']);
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('charges_sub_group');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientsOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients_orders', function (Blueprint $table) {
            $table->string('patient_id',50)->references('patient_id')->on('patients');
            $table->integer('visit_no');
            $table->string('order_no',10);
            $table->string('charge_no',20);
            $table->dateTime('order_dt');
            $table->string('order_status',1)->nullable();
            $table->string('sample_id',60);
            $table->decimal('charge_prc', 15, 2)->nullable();
            $table->decimal('charge_disc_perc1', 15, 2)->nullable();
            $table->decimal('charge_disc_perc2', 15, 2)->nullable();
            $table->decimal('charge_prc_dis', 15, 2)->nullable();
            $table->decimal('tot_amnt', 15, 2)->nullable();
            $table->decimal('tot_disc', 15, 2)->nullable();
            $table->decimal('net_amnt', 15, 2)->nullable();
            $table->string('order_notes',255);
            $table->string('lab_flg',1);
            $table->string('comp_cd', 10)->nullable();
            $table->timestamps();
            $table->primary(['patient_id','visit_no','order_no','charge_no']);
         });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients_orders');
    }
}

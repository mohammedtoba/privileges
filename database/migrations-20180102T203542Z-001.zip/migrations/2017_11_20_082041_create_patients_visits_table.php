<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientsVisitsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients_visits', function (Blueprint $table) {
            $table-> string('patient_id',50)->references('patient_id')->on('patients') ;
            $table->integer('visit_no');
            $table->dateTime('visit_dt');
            $table->string('visit_sts',1)->nullable();
            $table->string('visit_flg', 1)->nullable();
            $table->string('comp_type',3)->nullable();
            $table->string('comp_cd', 10)->nullable();
            $table->string('refer_flg',1)->nullable();
            $table->string('refer_cd', 10)->nullable();
            $table->decimal('amount', 15, 2)->nullable();
            $table->timestamps();
            $table->primary(['patient_id', 'visit_no']);
       });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients_visits');
    }
}
